import os

# libpng 경고를 포함한 하위 시스템 메시지를 숨깁니다.
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide" # Pygame 환영 메시지 숨기기
os.environ['SDL_VIDEO_X11_WMCLASS'] = " " # 관련 없는 경고 방지

import pygame
import sys
import random
import time
import base64
import io
import math

pygame.init()

# ── 해상도 / 전체화면 ──────────────────────────────────────────
NATIVE_W, NATIVE_H = 852, 600
WIDTH,    HEIGHT   = NATIVE_W, NATIVE_H
FPS = 60

is_fullscreen = False
screen = pygame.display.set_mode((NATIVE_W, NATIVE_H))
pygame.display.set_caption("FEVER BREAK")

buffer = pygame.Surface((NATIVE_W, NATIVE_H))

def toggle_fullscreen():
    global screen, is_fullscreen
    is_fullscreen = not is_fullscreen
    if is_fullscreen:
        screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    else:
        screen = pygame.display.set_mode((NATIVE_W, NATIVE_H))

def blit_scaled(src, dst_screen):
    sw, sh = dst_screen.get_size()
    scale  = min(sw / NATIVE_W, sh / NATIVE_H)
    new_w  = int(NATIVE_W * scale)
    new_h  = int(NATIVE_H * scale)
    ox     = (sw - new_w) // 2
    oy     = (sh - new_h) // 2
    scaled = pygame.transform.scale(src, (new_w, new_h))
    dst_screen.fill((0, 0, 0))
    dst_screen.blit(scaled, (ox, oy))

# ── 색상 ──────────────────────────────────────────────────────
WHITE      = (255, 255, 255)
GRAY       = (40,  40,  40)
DARK_GRAY  = (20,  20,  20)
RED        = (220, 50,  50)
YELLOW     = (240, 200, 0)
BLUE       = (50,  120, 220)
GREEN      = (50,  200, 50)
SOFT_FEVER = (60,  45,  45)

# ── 블록 ──────────────────────────────────────────────────────
BLOCK_W, BLOCK_H = 72, 22
BLOCK_COLS       = 11
BLOCK_MARGIN     = 5
BLOCK_TOP        = 80

COLOR_RED    = (220, 50,  50)
COLOR_BLUE   = (50,  120, 220)
COLOR_YELLOW = (240, 200, 0)
COLOR_GREEN  = (50,  200, 50)
BLOCK_COLOR_LIST = [COLOR_RED, COLOR_BLUE, COLOR_YELLOW, COLOR_GREEN]

PAD_W, PAD_H = 100, 12
BALL_R       = 8
FEVER_SCALE  = 2

# ── 화면 흔들기 ────────────────────────────────────────────────
shake_amount = 0

def trigger_shake(amount=10):
    global shake_amount
    shake_amount = amount

def get_shake_offset():
    global shake_amount
    if shake_amount > 0:
        ox = random.randint(-shake_amount, shake_amount)
        oy = random.randint(-shake_amount, shake_amount)
        shake_amount = max(0, shake_amount - 1)
        return ox, oy
    return 0, 0

clock = pygame.time.Clock()

# ── 블록 이미지 ────────────────────────────────────────────────
def load_block_images():
    paths = {
        COLOR_RED:    "./assets/images/24-Breakout-Tiles.png",
        COLOR_BLUE:   "./assets/images/27-Breakout-Tiles.png",
        COLOR_YELLOW: "./assets/images/26-Breakout-Tiles.png",
        COLOR_GREEN:  "./assets/images/22-Breakout-Tiles.png",
    }
    imgs = {}
    for color, path in paths.items():
        try:
            img = pygame.image.load(path).convert_alpha()
            imgs[color] = pygame.transform.scale(img, (BLOCK_W, BLOCK_H))
        except Exception:
            surf = pygame.Surface((BLOCK_W, BLOCK_H))
            surf.fill(color)
            imgs[color] = surf
    return imgs

block_images = load_block_images()

# ── 스킬 버튼 이미지 ──────────────────────────────────────────
try:
    skill_img_raw = pygame.image.load("./assets/images/skill_button.png").convert_alpha()
    skill_img = pygame.transform.scale(skill_img_raw, (44, 44))
except Exception:
    skill_img = None

# ── 폰트 (한글 지원) ────────────────────────────────────────
import os

def make_font(size, bold=False):
    candidates = [
        r"C:/Windows/Fonts/malgun.ttf",
        r"C:/Windows/Fonts/malgunbd.ttf",
        r"C:/Windows/Fonts/gulim.ttc",
        r"C:/Windows/Fonts/dotum.ttc",
        r"C:/Windows/Fonts/NanumGothic.ttf",
        "/Library/Fonts/AppleGothic.ttf",
        "/System/Library/Fonts/AppleSDGothicNeo.ttc",
        "/usr/share/fonts/truetype/nanum/NanumGothic.ttf",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    ]
    for path in candidates:
        if os.path.exists(path):
            try:
                return pygame.font.Font(path, size)
            except Exception:
                continue
    for name in ["malgungothic", "malgun gothic", "gulim", "nanumgothic"]:
        try:
            return pygame.font.SysFont(name, size, bold=bold)
        except Exception:
            continue
    return pygame.font.SysFont(None, size, bold=bold)

font       = make_font(22)
ui_font    = make_font(17)
big_font   = make_font(58)
fever_font = make_font(76)
small_font = make_font(14)

def make_title_font(size):
    win_candidates = [
        r"C:/Windows/Fonts/impact.ttf",
        r"C:/Windows/Fonts/AGENCYB.TTF",
        r"C:/Windows/Fonts/BERNHC.TTF",
        r"C:/Windows/Fonts/ariblk.ttf",
        r"C:/Windows/Fonts/GOTHICB.TTF",
        r"C:/Windows/Fonts/arialbd.ttf",
        r"C:/Windows/Fonts/BRLNSB.TTF",
        r"C:/Windows/Fonts/trebucbd.ttf",
    ]
    mac_candidates = [
        "/System/Library/Fonts/Impact.ttf",
        "/Library/Fonts/Impact.ttf",
    ]
    for p in win_candidates + mac_candidates:
        if os.path.exists(p):
            try:
                return pygame.font.Font(p, size)
            except Exception:
                continue
    for name in ["impact", "agencyfb", "ariblack", "arial black"]:
        try:
            return pygame.font.SysFont(name, size, bold=True)
        except Exception:
            continue
    return pygame.font.SysFont(None, size, bold=True)

title_font       = make_title_font(64)
go_font          = make_title_font(72)
fever_title_font = make_title_font(80)

en_font       = pygame.font.SysFont("arial", 20, bold=True)
en_big_font   = pygame.font.SysFont("arial", 38, bold=True)
en_ui_font    = pygame.font.SysFont("arial", 17, bold=True)
en_small_font = pygame.font.SysFont("arial", 13, bold=True)

# ── 사운드 ────────────────────────────────────────────────────
def load_sound(path):
    try:
        return pygame.mixer.Sound(path)
    except Exception:
        return None

shoot_sound    = load_sound("./assets/sounds/mixkit-twig-breaking-2945.wav")
skill_sound    = load_sound("./assets/sounds/u_lfmkadc0ha-timer_countdown-345137.mp3")
gameover_sound = load_sound("./assets/sounds/767605__minimalistiga__gameover-sfx.wav")

skill_active_time      = 0
is_skill_sound_playing = False
skill_channel = pygame.mixer.Channel(1)

# ── 하트 스프라이트 ────────────────────────────────────────────
HEART_B64 = "iVBORw0KGgoAAAANSUhEUgAAAUAAAAAgCAYAAABjE6FEAAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAAAiVSURBVHic7Z09axxHGMefVQrZbpTCPsmExAkBqbDBdmHjQjiEcOmCG4Mate70CfwB/AncpXVjSGPS5QghQuDgxk0aCULeCL6TXfgw6OQi3hS3z+y8PPO6M7N38fxBcNLtzG9mZ57/PjO3twIoKioqKioqKip6v1Tp3qjPQa0cfKI/PlbZwi/8wi/8XHzlj1i4OiErNlbWpWzhF37hF35ufiUdVPOFa7jIHfhCqEyuqEtZbR27e/MXk5dQjR7n569tAty8Pq/Dl7+22fKnR2H8re22jsMDP75HWW0d23faOg6e+PE9yha+po6+x99jDitlhzvzF8+eh8//Lv4z3AFYvzAv++ihtmxFVcCDZWFD+Iq6lCX5aHwAAJOX7evRfh4+DnxjfngiAdqTqeVzk0bhNxPByucmL9MnH83raIxYy6fKIr8JBCufC16ljiaYtXzPsoVP8D3HUCiLxvPXP05lSb7nHLbG7rPn2rIkv6v/DG+3BSyxq1QwhgGswwfaBsiNAJinnKZGe3WAOoGj/Wz8MQxgfe1D0vywTbwJMb5h0gh82wRavQTw6cdqwcYAYf2CMJCMbwgagW8LoMEVgM3PzXVwgcz4hsDXlS18j/Hn6+DGkPG3tgFuXGtjhjBAuaxx/pv43BxmfFwtEfECAEYTTOY/aIQGE1zhjx/DwAhGuZqNb1kX80vJt/a/aZOr2ZF8Q9l69RL9BpofHsefJ1++wSjrwRW3OjDLCOEbjMKZ72g2S8fXjb98HDWGN66Jv0tzxli2kXP8m+Y/v2LzLBvdf9A7uDbJsbMir51dVcNFqE78si9e1cnc+Um+wfyy8KnsT7qS1WubLT/AEI18nbj21Lt7Ld8x++vMBwA4e0blBxhCML9Rffdey797Lz9/+07L392bn5fm3GThb22LfJScgaXiU/O/iQ3BBLE9GFOx+K7xT5ggz6+wAbz72lLQGKrghZjCch94AIDR/FLwhf4Pv2xeXBDbhAMcgz89EvvPX/3lJRC3/GWyLHWs/MMDkc9nP6YlIAY5f25mp/78gydhfNTGAGDzs/nro98Bxsd5+QDzcyHPEcdzofBN429S4NyQx1+Y/5YlsFVyAkHEjzz/k/uPtByuHj2E+hwAWwJP4R07dgL/xm+Ahyajn7Izsf+K+aEimh+lydtZ+8sff7evqQmOCjQ/SqfHr9pfjn4zH+yYZXhp+sadn0Be/afU8Zxox98mag5gWzTLYEpC/E9fu/MpybGiyQK1/BT+o0moVsi/9iXL/kEvKm0qWgYt4pxYgjYJBsi7cHY1Desj+0Ox/mfO/lBCFqA9qNvS1yQhC6LksccVJD4L7EHW/ruowzlyGn9KOBc6Gk7U+Ndlgbn4lIj9QGaAWxBh8B3F39TI/jZ6DEejH3vjb8Er2Bx+Jf4x0RWMvzEUtQHEHpZp+duFz90YizoL46gMI5+7MZj97e2fvfL77j85/l1kWAZT458s/uUYunmdnP/Z/Ge0L3ypYaU6gQo3IwFaF069D4j34SwaP1f2p+OzLIDaB4qY/en4LAvS7YPJm+0BH4CY+CwLTLwPGNx/XrNT+hPPDnzj+JvkmQVa46/rPiCAMQtclPgXlsA5XJjKvhaFz18ZcmZ/qOhZAMUnrv4oYxYUaflLZT/svQxZoIkfLQs0nCsTv+/xz5EFCjGWi89Jjv8VgLkT5nRh5ft4C8ZHpdqPtPGFvaAEn7ja+F5ZUAJ+6ixw0fsfnAXK0swd5/hLkQX68DPEv/IpMLpwikaYsq9F4fNfnAaINAmwbkP2h2JZwO1b4hsRlr+mqz8KsyCrCQRkyKbshx2DWWACE3ThO/efl+O5cOHj+AeZoG4ZjN8jdxh/Jf5izn8ptpz4ieOfGaAuC4rdCOqL0AvHn7wUPpCJOQm8+p8h+zPyUWgCcnsC9v868SMoOl8+B5YxC+J3yQSl9gTFX4z7AvFrpAsW/+R9gLILx2iES/a1KHzcp4h5c6hL9odS9oIi7Ee6XP1RShZ09XJ3vkP2w46Vs0CAzibow1f6H8KX9gF9+EoWCOBvgvJXvzzGn4y/rvPfsPfnxE8U/4IB8i6sa0RIQ0yPoVoq/vR10EQwPQZIxycnzP4vQdmA6TFIOj5pAoEyPQZKx9eaYIARhvC1JpiJrzVB2/hTj8EiHqFm4/c9/3PFv5IBUqmofINiSENsnV8qfsBE6MJX5BIIsfnUd01z8eUbpANMqAtfuQhQRmi5HaYLX7lBOvP49z3/U8a/8atw/MfSU3gX1BCfpefS8R0mgs/SVykrfyATEAg+Sx9Z1ttCHDIin6WfUpa/LWb6JuibIl34fP9Pj1+5GWFEPr8VMnk7Cxt/hw8edOp7/ueIf9IAqVQ0pCGuS8+l52smgmvqb+JTJugaCK5LXxPf6d44jRG4Lv1MfOXeQJ0RJuLL/SeNUFdPBL68H+w1/sQTkH35fc//1PFv/QclVfOsrkM4r7y/ZkggceB8O1/4NL8e7ij3Ja6vntWWReOIxpceVns6+hnODNRzwvjHv8blyw8L/eZr8XFY+0+T8mewobwv9P/qZevj17vwqYeFasf/9i3nfT9Xft/zPxXf2rBaemChrSH8FatL5wuf5tsCgc+YUvDr3T1mgCjeCNB4kvHRCDUGmJqvNcLGAE3/gCcGv+/x73v+x+Y7Na6W/t0c1QiANl1ly5eOnS98mq97dDh/1UvJr4c7ggGicLmYnL96STXA738Qst6UfNIEh19Q/yvmfzn+fc//mHyvBppSUh4eq+OFr+fLQRBjyeHDl02AN78c/PruPcEAq+++zcrvu/99j3/f878PPmsEwPznEM7Xh3Ce/Y5OnVKF3/LHMKjHMOiNP4ONegYbvfHr+w/q+v6D97b/fY9/3/M/Bj94cxKAW5JETnkLv/ALv/AXlS80JIfrF37hF37hLxq/qKioaKn1H3JtdcLE4vjPAAAAAElFTkSuQmCC"

sheet_bytes = base64.b64decode(HEART_B64)
heart_sheet = pygame.image.load(io.BytesIO(sheet_bytes)).convert_alpha()
FRAME_W, FRAME_H = 32, 32
heart_frames = []
for _i in range(10):
    _r = pygame.Rect(_i * FRAME_W, 0, FRAME_W, FRAME_H)
    heart_frames.append(pygame.transform.scale(heart_sheet.subsurface(_r), (30, 30)))


# ══════════════════════════════════════════════════════════════
# ── 스킬 아이템 스프라이트 (Base64 내장) ──────────────────────
# ══════════════════════════════════════════════════════════════

SKILL_SHEET_B64 = "iVBORw0KGgoAAAANSUhEUgAAAFAAAAAQCAYAAACBSfjBAAACXElEQVRYR+WYy3ECMQyGTQNwDbf0QBspgg4y6YAOMumAItIGPXAjV2iA+PdKi2xLtnaZgZnEF2BZvT7LknYXwVgvy+VV/vVzuSyse7Xr98pDJ+uYalvKsm9TdXj9r6Cw4Ol8ybisV8v02+MIdJzOZ5KHiWtYr1YuWTY66Bh8gG2PXU2Wr3l1tOLXfMgASqfDvsir7ZCQPRAZvH1UD7n4eTiG8PbpB8G+HHbz5Er/Pfab8SP299r/EeAoXIIDNYIHEPjegjgCFPCgwhOA3LJHA2zGT45pMSSApvAW/1IpdGRTBS/Q/tCmeCGW/syVC8n/uDr2m/HLhFJOoQ1QwDvsFmGzG45iK5tuR4DujTpwBDevQxxzQEAGy3P8KxBO+ypAxB/hwX7yn+CBhfRFByjg8bFleH2AsXmkbCVozwI4wb4GXmZtSh4spYQZAHOBlIGURX2AsXPGnUvLmQF09/ghA3p2Bpb1v5+B3DBS/bp10H8J0FH/8wxUBDjj/gJAa4LQa+BwCnv1XwCkwZe7LTKQjuJYSOmQWc1gbhF/yBFuzLG13/XkwT6WsecAldkNgjL7ptRArl9zuzA6OK85XXi0T02grF+sOwNYzLyyeWqxF4M0ddAyJcTv1ijSG0a9YwzMJV1fF/foM8rg8Y+bWGpkdgeVYVpPUPIec5CudgIXpBOoBcfhrl4mWBCnwJsLsILohFfHf5t5+T/Lf/NlwvdH/jIB4LA8D/WAqMl7ZGUwrKO3aeWBkdnETaD3DC/t4rvXf/MVlfd1jnXa75XnbPJumgZRXpuyedI267DkfwErQyw+eVsjjwAAAABJRU5ErkJgggAA"

def load_skill_frames(display_size=32):
    raw   = base64.b64decode(SKILL_SHEET_B64)
    sheet = pygame.image.load(io.BytesIO(raw)).convert_alpha()
    frames = []
    fw, fh = 16, 16
    for i in range(5):
        rect  = pygame.Rect(i * fw, 0, fw, fh)
        frame = sheet.subsurface(rect)
        frames.append(pygame.transform.scale(frame, (display_size, display_size)))
    return frames

skill_item_frames = load_skill_frames(display_size=32)


# ── 절차적 스프라이트 생성 ────────────────────────────────────
# ── 새로운 패들 확장 아이템 스프라이트 (Base64) ────────────────

# 요청하신 4프레임 시트 데이터
EXPAND_SHEET_B64 = "iVBORw0KGgoAAAANSUhEUgAAAEAAAAAQCAYAAACm53kpAAAB00lEQVRYR+WXLUwDQRCFt74CAYbWIRCEhOQCAlESSDBUggCFIg2OYJFYgiMEhQIBssiSUIGAkDQhCHyLAYHAQ95d5rLM7czuVhAuXXVp782b+Xb25ypmxEdFq39yfvkb/7893qrvSTHKoBcLQ/JL23tpbXfnx9EQyqJ3AqDkPxbrZvy+Hw2B6xHnZWc/GCLpL3abqffWSTtqEmLyLwCwxQe1OXN61c47PKQTXOYIEArBLr77nlk3JsIhuPxpIl35/wLAi4e5DcC3HDR4IRB48eTd2mgGQZDgQ3846KXdzCEUAMycHRnMPJFf7WVCGloXIAHSc3Ch+sFDx2DmuZ4g1BZWxKVE/na+5EsQ+FIsALi86eTF4wHJEL2QDiD9sACgl7QoYnNNB0AbNz+ZoMXgeucS0I5GXwdICYR2wF/rCwDq69nRJ43+tXwkogXLpvcC+Hx9ylmMTScmFAB0eJ/0eMbw6auzjVTnGoj19dxV9wCaANuXcnH5RwFIkkQ9j3kHcHhTVf1SRXo7YQKB32L8uTfiuPyd9wC7jSmQz5wSdUHAjPqK53obQkjxLn87huQv3gTtVgotXkpiWH0sfAmiBl/9FiAI2rqVNku7E/6zfuS/Bn8A7AkgL+ijttcAAAAASUVORK5CYIIA"

def load_expand_frames(display_size=32):
    """Base64 데이터를 로드하여 4개의 프레임 리스트로 반환"""
    raw = base64.b64decode(EXPAND_SHEET_B64)
    sheet = pygame.image.load(io.BytesIO(raw)).convert_alpha()
    frames = []
    fw, fh = 16, 16 # 원본 한 프레임 크기
    for i in range(4): # 4개 프레임 자르기
        rect = pygame.Rect(i * fw, 0, fw, fh)
        frame = sheet.subsurface(rect)
        # 게임 화면 크기에 맞게 확대 (32x32)
        frames.append(pygame.transform.scale(frame, (display_size, display_size)))
    return frames

# 아이템 스프라이트 사전 (새로운 함수 적용)
item_sprite_frames = {
    "skill":  skill_item_frames,            # 기존 스킬 아이콘
    "expand": load_expand_frames(display_size=32), # 새로운 패들 아이콘
}
# ── ItemSprite 클래스 ─────────────────────────────────────────
class ItemSprite:
    FPS_SKILL  = 7    # 150ms 기준 (원본 FRAME_DELAY)
    FPS_EXPAND = 10

    def __init__(self, item_type, cx, cy):
        self.type      = item_type
        self.frames    = item_sprite_frames.get(item_type, [])
        self.frame_idx = 0
        self.timer     = 0.0
        self.fps       = self.FPS_SKILL if item_type == "skill" else self.FPS_EXPAND
        self.rect      = pygame.Rect(cx - 16, cy - 16, 32, 32)

    def update(self, dt_ms):
        self.rect.y += 3
        if self.frames:
            self.timer += dt_ms / 1000.0
            if self.timer >= 1.0 / self.fps:
                self.timer     = 0.0
                self.frame_idx = (self.frame_idx + 1) % len(self.frames)

    def draw(self, surf):
        if self.frames:
            surf.blit(self.frames[self.frame_idx], self.rect)
        else:
            # 폴백 도형
            if self.type == "expand":
                pygame.draw.rect(surf, BLUE, self.rect, border_radius=3)
            else:
                draw_plus(surf, self.rect)


# ══════════════════════════════════════════════════════════════
# ── 유틸 함수들 ───────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════

def draw_diamond(surf, pos, size, color, alpha=255):
    x, y = int(pos[0]), int(pos[1])
    s = max(1, int(size))
    tmp = pygame.Surface((s * 2 + 2, s * 2 + 2), pygame.SRCALPHA)
    pts = [(s, 0), (s * 2, s), (s, s * 2), (0, s)]
    col_a = (*color[:3], alpha)
    pygame.draw.polygon(tmp, col_a, pts)
    surf.blit(tmp, (x - s, y - s))

def draw_star(surf, pos, size, color, alpha=255):
    x, y = int(pos[0]), int(pos[1])
    s = max(1, int(size))
    tmp = pygame.Surface((s * 4, s * 4), pygame.SRCALPHA)
    cx, cy = s * 2, s * 2
    pts = [
        (cx,      cy - s*2),
        (cx + s//2, cy - s//2),
        (cx + s*2, cy),
        (cx + s//2, cy + s//2),
        (cx,      cy + s*2),
        (cx - s//2, cy + s//2),
        (cx - s*2, cy),
        (cx - s//2, cy - s//2),
    ]
    col_a = (*color[:3], alpha)
    pygame.draw.polygon(tmp, col_a, pts)
    surf.blit(tmp, (x - s*2, y - s*2))

class StarParticle:
    def __init__(self, w, h):
        self.x = random.uniform(0, w)
        self.y = random.uniform(0, h)
        self.size = random.uniform(1, 3)
        self.speed = random.uniform(0.3, 1.2)
        self.alpha = random.randint(80, 255)
        self.fade_dir = random.choice([-1, 1])
        self.color = random.choice([WHITE, YELLOW, (180, 180, 255), (255, 180, 180)])

    def update(self):
        self.y += self.speed
        self.alpha += self.fade_dir * 3
        if self.alpha >= 255 or self.alpha <= 80:
            self.fade_dir *= -1
        self.alpha = max(0, min(255, self.alpha))
        if self.y > HEIGHT:
            self.y = 0
            self.x = random.uniform(0, WIDTH)

    def draw(self, surf):
        a = max(0, min(255, int(self.alpha)))
        s = pygame.Surface((int(self.size*2)+2, int(self.size*2)+2), pygame.SRCALPHA)
        pygame.draw.circle(s, (*self.color, a), (int(self.size)+1, int(self.size)+1), int(self.size))
        surf.blit(s, (int(self.x), int(self.y)))

def draw_scanlines(surf, alpha=18):
    w, h = surf.get_size()
    scan = pygame.Surface((w, h), pygame.SRCALPHA)
    for y in range(0, h, 3):
        pygame.draw.line(scan, (0, 0, 0, alpha), (0, y), (w, y))
    surf.blit(scan, (0, 0))

def draw_text_buf(surf, text, x, y, color=WHITE, fnt=None, center=False):
    if fnt is None: fnt = font
    img  = fnt.render(text, True, color)
    rect = img.get_rect(topleft=(x, y))
    if center: rect.centerx = x
    surf.blit(img, rect)

def draw_text_shadow(surf, text, x, y, color=WHITE, fnt=None, center=False, shadow_col=(0,0,0), offset=2):
    if fnt is None: fnt = font
    shadow = fnt.render(text, True, shadow_col)
    main   = fnt.render(text, True, color)
    rx = x - main.get_width()//2 if center else x
    surf.blit(shadow, (rx + offset, y + offset))
    surf.blit(main,   (rx, y))

def load_highscore():
    try:
        with open("highscore.txt") as f: return int(f.read())
    except: return 0

def save_highscore(score):
    with open("highscore.txt", "w") as f: f.write(str(score))

def make_blocks(rows, start_y):
    blocks = []
    for r in range(rows):
        for c in range(BLOCK_COLS):
            x     = BLOCK_MARGIN + c * (BLOCK_W + BLOCK_MARGIN)
            y     = start_y + r * (BLOCK_H + BLOCK_MARGIN)
            color = random.choice(BLOCK_COLOR_LIST)
            blocks.append({
                "rect":  pygame.Rect(x, y, BLOCK_W, BLOCK_H),
                "color": color,
                "image": block_images[color],
                "drop_chance": 0.6 if color == COLOR_YELLOW else 0.10,
            })
    return blocks

def create_ball(x, y, vx, vy):
    r = pygame.Rect(x - BALL_R, y - BALL_R, BALL_R * 2, BALL_R * 2)
    return {"rect": r, "vx": vx, "vy": vy, "trail": []}

def draw_plus(surf, rect):
    pygame.draw.rect(surf, YELLOW, rect, border_radius=3)
    cx, cy = rect.centerx, rect.centery
    bar_w  = rect.w - 6
    pygame.draw.rect(surf, GRAY, (cx - bar_w//2, cy - 2, bar_w, 4))
    pygame.draw.rect(surf, GRAY, (cx - 2, cy - bar_w//2, 4, bar_w))

def draw_yellow_block_highlight(surf, rect, t):
    pulse = abs(math.sin(t * 3)) * 0.7 + 0.3
    alpha = int(200 * pulse)
    s = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
    pygame.draw.rect(s, (255, 255, 255, alpha), (0, 0, rect.w, rect.h), 2, border_radius=2)
    surf.blit(s, rect.topleft)
    star_x = rect.right - 10
    star_y = rect.top + 4
    draw_diamond(surf, (star_x, star_y), 4, (255, 255, 180), int(180 * pulse))

def draw_bg_grid(surf, t):
    w, h = surf.get_size()
    step = 40
    alpha = 15
    grid = pygame.Surface((w, h), pygame.SRCALPHA)
    for x in range(0, w, step):
        pygame.draw.line(grid, (255, 255, 255, alpha), (x, 0), (x, h))
    for y in range(0, h, step):
        pygame.draw.line(grid, (255, 255, 255, alpha), (0, y), (w, y))
    surf.blit(grid, (0, 0))

def combo_color(ratio):
    r = int(YELLOW[0] + (RED[0] - YELLOW[0]) * ratio)
    g = int(YELLOW[1] + (RED[1] - YELLOW[1]) * ratio)
    b = int(YELLOW[2] + (RED[2] - YELLOW[2]) * ratio)
    return (r, g, b)


# ── 시작 화면 ─────────────────────────────────────────────────
def start_screen(highscore=0):
    stars = [StarParticle(WIDTH, HEIGHT) for _ in range(80)]
    t = 0
    while True:
        dt = clock.tick(FPS)
        t += dt / 1000.0

        buffer.fill(DARK_GRAY)

        grad = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        for i in range(HEIGHT):
            a = int(60 * (1 - i / HEIGHT))
            pygame.draw.line(grad, (0, 0, 40, a), (0, i), (WIDTH, i))
        buffer.blit(grad, (0, 0))

        for s in stars:
            s.update()
            s.draw(buffer)

        draw_bg_grid(buffer, t)

        glow_alpha = int(abs(math.sin(t * 1.5)) * 60 + 40)
        glow_surf  = title_font.render("FEVER BREAK", True, YELLOW)
        glow_s = pygame.Surface(glow_surf.get_size(), pygame.SRCALPHA)
        glow_s.blit(glow_surf, (0, 0))
        glow_s.set_alpha(glow_alpha)
        for ox, oy in [(-3,0),(3,0),(0,-3),(0,3)]:
            buffer.blit(glow_s, (WIDTH//2 - glow_surf.get_width()//2 + ox, 100 + oy))

        draw_text_shadow(buffer, "FEVER BREAK", WIDTH//2, 100, WHITE, title_font, center=True,
                         shadow_col=(80, 60, 0), offset=3)

        if int(t * 2) % 2 == 0:
            draw_text_shadow(buffer, "R 키를 눌러 시작!", WIDTH//2, 220, YELLOW, font, center=True)

        box = pygame.Rect(WIDTH//2 - 180, 280, 360, 80)
        pygame.draw.rect(buffer, (30, 30, 50), box, border_radius=10)
        pygame.draw.rect(buffer, (80, 80, 120), box, 1, border_radius=10)
        draw_text_buf(buffer, "← → / A D  :  패들 이동", WIDTH//2, 295, (170, 170, 200), ui_font, center=True)
        draw_text_buf(buffer, "E : 발사 / 스킬     Q : 일시정지", WIDTH//2, 325, (170, 170, 200), ui_font, center=True)

        tip_box = pygame.Rect(WIDTH//2 - 170, 380, 340, 36)
        pygame.draw.rect(buffer, (50, 45, 10), tip_box, border_radius=8)
        pygame.draw.rect(buffer, YELLOW, tip_box, 1, border_radius=8)
        draw_text_buf(buffer, "★ 노란 블록 = 아이템 드롭 UP!", WIDTH//2, 389,
                      YELLOW, small_font, center=True)

        desc_box = pygame.Rect(WIDTH//2 - 190, 435, 380, 100)
        pygame.draw.rect(buffer, (20, 20, 35), desc_box, border_radius=10)
        pygame.draw.rect(buffer, (60, 60, 100), desc_box, 1, border_radius=10)

        draw_text_buf(buffer, "가장 높은 점수를 얻어보세요!",
                      WIDTH//2, 448, (200, 200, 255), small_font, center=True)
        draw_text_buf(buffer, "블록을 부수면 콤보가 쌓이고,",
                      WIDTH//2, 470, (160, 160, 200), small_font, center=True)
        draw_text_buf(buffer, f"8콤보 달성 시 FEVER 타임 돌입!",
                      WIDTH//2, 490, (160, 160, 200), small_font, center=True)

        hs_col = YELLOW if highscore > 0 else (100, 100, 100)
        hs_text = f"최고 기록 : {highscore:,} 점" if highscore > 0 else "최고 기록 : 없음"
        draw_text_buf(buffer, hs_text, WIDTH//2, 512, hs_col, small_font, center=True)

        txt = small_font.render("F11 : 전체화면", True, (80, 80, 80))
        buffer.blit(txt, (WIDTH - txt.get_width() - 10, HEIGHT - 25))

        draw_scanlines(buffer)
        blit_scaled(buffer, screen)
        pygame.display.flip()

        for e in pygame.event.get():
            if e.type == pygame.QUIT: pygame.quit(); sys.exit()
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_r: return
                if e.key == pygame.K_F11: toggle_fullscreen()


def draw_pause_overlay():
    NEON_BLUE = (0, 255, 255)
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    buffer.blit(overlay, (0, 0))

    glow_surf = title_font.render("PAUSED", True, (0, 200, 200))
    text_rect = glow_surf.get_rect(center=(WIDTH//2, HEIGHT//2 - 40))
    glow_layer = pygame.Surface(glow_surf.get_size(), pygame.SRCALPHA)
    glow_layer.blit(glow_surf, (0, 0))
    for offset in range(1, 8):
        a = max(0, 80 - offset * 10)
        glow_layer.set_alpha(a)
        buffer.blit(glow_layer, (text_rect.x + offset, text_rect.y))
        buffer.blit(glow_layer, (text_rect.x - offset, text_rect.y))
        buffer.blit(glow_layer, (text_rect.x, text_rect.y + offset))
        buffer.blit(glow_layer, (text_rect.x, text_rect.y - offset))

    main_surf = title_font.render("PAUSED", True, WHITE)
    buffer.blit(main_surf, text_rect)

    sub_str  = "C : Continue      Q : Quit"
    sub_surf = font.render(sub_str, True, (160, 160, 160))
    sub_rect = sub_surf.get_rect(center=(WIDTH//2, HEIGHT//2 + 55))

    line_y  = sub_rect.centery
    line_len = 60
    pygame.draw.line(buffer, (100,100,100),
                     (sub_rect.left - line_len - 10, line_y),
                     (sub_rect.left - 10,            line_y), 1)
    pygame.draw.line(buffer, (100,100,100),
                     (sub_rect.right + 10,            line_y),
                     (sub_rect.right + line_len + 10, line_y), 1)
    buffer.blit(sub_surf, sub_rect)

    tip = small_font.render("Q : 게임 종료", True, (180, 80, 80))
    buffer.blit(tip, (WIDTH//2 - tip.get_width()//2, HEIGHT//2 + 90))


def pause_menu():
    try: pygame.mixer.music.pause()
    except: pass
    while True:
        draw_pause_overlay()
        draw_scanlines(buffer)
        blit_scaled(buffer, screen)
        pygame.display.flip()
        for e in pygame.event.get():
            if e.type == pygame.QUIT: pygame.quit(); sys.exit()
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_c:
                    try: pygame.mixer.music.unpause()
                    except: pass
                    return
                if e.key == pygame.K_q: pygame.quit(); sys.exit()
                if e.key == pygame.K_F11: toggle_fullscreen()


def game_over_screen(score, highscore):
    if score > highscore: save_highscore(score)
    new_best = score > highscore
    stars = [StarParticle(WIDTH, HEIGHT) for _ in range(60)]
    t = 0
    while True:
        dt = clock.tick(FPS)
        t += dt / 1000.0

        buffer.fill((15, 5, 5))

        grad = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        for i in range(HEIGHT):
            a = int(40 * (1 - i / HEIGHT))
            pygame.draw.line(grad, (60, 0, 0, a), (0, i), (WIDTH, i))
        buffer.blit(grad, (0, 0))

        for s in stars:
            s.update()
            s.draw(buffer)

        glow_alpha = int(abs(math.sin(t * 2)) * 80 + 40)
        gw = go_font.render("GAME OVER", True, RED)
        gs = pygame.Surface(gw.get_size(), pygame.SRCALPHA)
        gs.blit(gw, (0, 0))
        gs.set_alpha(glow_alpha)
        for ox, oy in [(-4,0),(4,0),(0,-4),(0,4)]:
            buffer.blit(gs, (WIDTH//2 - gw.get_width()//2 + ox, 150 + oy))

        draw_text_shadow(buffer, "GAME OVER", WIDTH//2, 150, RED, go_font, center=True,
                         shadow_col=(80, 0, 0), offset=4)

        score_box = pygame.Rect(WIDTH//2 - 180, 270, 360, 110)
        pygame.draw.rect(buffer, (25, 15, 15), score_box, border_radius=12)
        pygame.draw.rect(buffer, RED, score_box, 1, border_radius=12)

        draw_text_buf(buffer, f"SCORE : {score:,}", WIDTH//2, 285, WHITE, font, center=True)

        best_val = max(score, highscore)
        best_col = YELLOW if new_best else (180, 180, 180)
        draw_text_buf(buffer, f"BEST  : {best_val:,}", WIDTH//2, 325, best_col, font, center=True)

        if new_best and int(t * 3) % 2 == 0:
            draw_text_buf(buffer, "✨ NEW RECORD!", WIDTH//2, 358, YELLOW, small_font, center=True)

        if int(t * 2) % 2 == 0:
            draw_text_buf(buffer, "R : 다시 시작     Q : 종료", WIDTH//2, 415, (200, 200, 200), ui_font, center=True)

        draw_scanlines(buffer)
        blit_scaled(buffer, screen)
        pygame.display.flip()

        for e in pygame.event.get():
            if e.type == pygame.QUIT: pygame.quit(); sys.exit()
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_r: return True
                if e.key == pygame.K_q: pygame.quit(); sys.exit()
                if e.key == pygame.K_F11: toggle_fullscreen()


# ── 메인 ──────────────────────────────────────────────────────
def main():
    global shake_amount, is_skill_sound_playing, skill_active_time
    global WIDTH, HEIGHT, buffer

    highscore = load_highscore()
    start_screen(highscore)

    try:
        pygame.mixer.music.load("./assets/sounds/A walk.mp3")
        pygame.mixer.music.set_volume(0.3)
        pygame.mixer.music.play(-1)
    except: pass

    pad   = pygame.Rect(WIDTH//2 - PAD_W//2, HEIGHT - 80, PAD_W, PAD_H)
    score = 0
    lives = 3
    level = 1
    skills      = 0
    blink_timer = 0
    game_time   = 0.0
    score_anim_timer = 0.0

    combo      = 0
    combo_time = 0
    FEVER_LIMIT    = 10
    FEVER_TARGET   = 8
    FEVER_DURATION = 8

    fever     = False
    fever_end = 0
    fever_flash_end = 0

    level_timer         = time.time()
    low_block_triggered = False

    heart_idx   = 0
    heart_timer = 0

    blocks     = make_blocks(3, BLOCK_TOP)
    items      = []        # ItemSprite 인스턴스 리스트
    particles  = []

    waiting   = False
    wait_ball = None

    paddle_normal_w   = PAD_W
    paddle_expanded_w = 150
    paddle_duration   = 0.0

    balls = [create_ball(WIDTH//2, HEIGHT//2, 5, -5)]

    while True:
        dt  = clock.tick(FPS)
        now = time.time()
        game_time += dt / 1000.0

        heart_timer += dt
        if heart_timer > 110:
            heart_idx   = (heart_idx + 1) % 10
            heart_timer = 0

        blink_timer += 1

        if is_skill_sound_playing:
            if now - skill_active_time > 1.0:
                skill_channel.stop()
                is_skill_sound_playing = False

        # ── 이벤트 ────────────────────────────────────────────
        for e in pygame.event.get():
            if e.type == pygame.QUIT: pygame.quit(); sys.exit()
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE or e.key == pygame.K_q:
                    pause_menu()
                if e.key == pygame.K_F11:
                    toggle_fullscreen()
                if e.key == pygame.K_e:
                    if waiting and wait_ball:
                        wait_ball["vy"] = -6
                        wait_ball["vx"] = random.choice([-5, 5])
                        balls.append(wait_ball)
                        wait_ball = None
                        waiting   = False
                    elif skills > 0:
                        skills -= 1
                        new_b = create_ball(
                            pad.centerx, pad.top,
                            random.choice([-4, 4]), -6
                        )
                        if fever:
                            cx, cy = new_b["rect"].center
                            s = BALL_R * 2 * FEVER_SCALE
                            new_b["rect"].size   = (s, s)
                            new_b["rect"].center = (cx, cy)
                        balls.append(new_b)

        # ── 패들 이동 ──────────────────────────────────────────
        keys = pygame.key.get_pressed()
        if (keys[pygame.K_a] or keys[pygame.K_LEFT])  and pad.left  > 0: pad.x -= 7
        if (keys[pygame.K_d] or keys[pygame.K_RIGHT]) and pad.right < WIDTH: pad.x += 7

        if waiting and wait_ball:
            wait_ball["rect"].centerx = pad.centerx
            wait_ball["rect"].bottom  = pad.top - 2

        # ── 공 물리 ────────────────────────────────────────────
        for b in balls[:]:
            b["trail"].append((b["rect"].center, BALL_R if not fever else BALL_R * FEVER_SCALE))
            if len(b["trail"]) > 10: b["trail"].pop(0)

            prev = b["rect"].copy()
            b["rect"].x += b["vx"]
            b["rect"].y += b["vy"]

            if b["rect"].left <= 0:
                b["rect"].left = 0; b["vx"] = abs(b["vx"])
            if b["rect"].right >= WIDTH:
                b["rect"].right = WIDTH; b["vx"] = -abs(b["vx"])
            if b["rect"].top <= 50:
                b["rect"].top = 50; b["vy"] = abs(b["vy"])

            if b["rect"].colliderect(pad) and b["vy"] > 0:
                offset  = (b["rect"].centerx - pad.centerx) / (PAD_W / 2)
                b["vx"] = offset * 7
                b["vy"] = -abs(b["vy"])

            hits = [blk for blk in blocks if b["rect"].colliderect(blk["rect"])]
            if hits:
                hit_rect = hits[0]["rect"]
                if shoot_sound:
                    shoot_sound.stop()
                    shoot_sound.play()
                for blk in hits:
                    blocks.remove(blk)
                    score += 10

                    # 기존 circle 파티클 (블록 색상 반영)
                    for _ in range(8):
                        particles.append([
                            blk["rect"].centerx, blk["rect"].centery,
                            random.uniform(-3, 3), random.uniform(-3, 3), 20,
                            blk["color"]
                        ])

                    trigger_shake(6)

                    if random.random() < blk["drop_chance"]:
                        item_type = "expand" if random.random() < 0.5 else "skill"
                        # ★ ItemSprite 인스턴스로 생성
                        items.append(ItemSprite(item_type, blk["rect"].centerx, blk["rect"].centery))

                if prev.bottom <= hit_rect.top or prev.top >= hit_rect.bottom:
                    b["vy"] *= -1
                else:
                    b["vx"] *= -1

                if combo == 0: combo_time = now
                combo += 1

                if now - combo_time <= FEVER_LIMIT and combo >= FEVER_TARGET and not fever:
                    fever     = True
                    fever_end = now + FEVER_DURATION
                    combo     = 0
                    for ball in balls:
                        cx, cy = ball["rect"].center
                        s = BALL_R * 2 * FEVER_SCALE
                        ball["rect"].size   = (s, s)
                        ball["rect"].center = (cx, cy)
                    fever_flash_end = now + 1.2
                    trigger_shake(15)
                elif now - combo_time > FEVER_LIMIT:
                    combo      = 1
                    combo_time = now

            if b["rect"].bottom >= HEIGHT:
                balls.remove(b)

        if not balls and not waiting:
            lives -= 1
            if lives <= 0:
                try: pygame.mixer.music.stop()
                except: pass
                if gameover_sound: gameover_sound.play()
                if game_over_screen(score, highscore):
                    main(); return
            wait_ball = create_ball(pad.centerx, pad.top - BALL_R - 2, 0, 0)
            waiting   = True

        if fever and now > fever_end:
            fever = False
            for ball in balls:
                cx, cy = ball["rect"].center
                ball["rect"].size   = (BALL_R * 2, BALL_R * 2)
                ball["rect"].center = (cx, cy)

        # ── 아이템 업데이트 & 충돌 ────────────────────────────
        for item in items[:]:
            item.update(dt)
            if item.rect.colliderect(pad):
                items.remove(item)
                if item.type == "expand":
                    paddle_duration = 7.0
                    cx = pad.centerx
                    pad.width = paddle_expanded_w
                    pad.centerx = cx
                    if pad.right > WIDTH: pad.right = WIDTH
                    if pad.left  < 0:    pad.left  = 0
                else:
                    skills += 1
                if skill_sound:
                    skill_channel.stop()
                    skill_channel.play(skill_sound)
                    skill_active_time      = now
                    is_skill_sound_playing = True
            elif item.rect.top > HEIGHT:
                items.remove(item)

        # ── 패들 확장 시간 제한 ───────────────────────────────
        if paddle_duration > 0:
            paddle_duration -= dt / 1000.0
            if paddle_duration <= 0:
                paddle_duration = 0.0
                cx = pad.centerx
                pad.width = paddle_normal_w
                pad.centerx = cx
                if pad.right > WIDTH: pad.right = WIDTH
                if pad.left  < 0:    pad.left  = 0

        # ── 블록 보충 ──────────────────────────────────────────
        if len(blocks) <= 10 and not low_block_triggered:
            score += 30
            for blk in blocks: blk["rect"].y += (BLOCK_H + BLOCK_MARGIN) * 2
            blocks.extend(make_blocks(2, BLOCK_TOP))
            low_block_triggered = True
        if len(blocks) > 10:
            low_block_triggered = False

        if now - level_timer > 180:
            level_timer = now
            for blk in blocks: blk["rect"].y += (BLOCK_H + BLOCK_MARGIN) * 2
            blocks.extend(make_blocks(2, BLOCK_TOP))

        for blk in blocks:
            if blk["rect"].bottom >= pad.top:
                try: pygame.mixer.music.stop()
                except: pass
                if gameover_sound: gameover_sound.play()
                if game_over_screen(score, highscore):
                    main(); return

        # ── 파티클 ────────────────────────────────────────────
        for p in particles[:]:
            p[0] += p[2]; p[1] += p[3]; p[4] -= 1
            if p[4] <= 0: particles.remove(p)

        # ════════════════════════════════════════════════════════
        # 그리기
        # ════════════════════════════════════════════════════════
        buffer.fill(SOFT_FEVER if fever else GRAY)
        draw_bg_grid(buffer, game_time)

        # 블록
        for blk in blocks:
            buffer.blit(blk["image"], blk["rect"])
            if blk["color"] == COLOR_YELLOW:
                draw_yellow_block_highlight(buffer, blk["rect"], game_time)

        # 공 잔상
        for b in balls:
            trail_len = len(b["trail"])
            for i, (pos, rad) in enumerate(b["trail"]):
                frac  = (i + 1) / trail_len
                alpha = int(180 * frac)
                size  = max(1, int(rad * (0.4 + 0.6 * frac)))
                if fever:
                    trail_col = (255, int(80 + 160 * frac), 0)
                else:
                    v = int(180 + 75 * frac)
                    trail_col = (v, v, 255)
                s = pygame.Surface((size * 2 + 2, size * 2 + 2), pygame.SRCALPHA)
                pygame.draw.circle(s, (*trail_col, alpha), (size + 1, size + 1), size)
                buffer.blit(s, (pos[0] - size - 1, pos[1] - size - 1))

            pygame.draw.ellipse(buffer, WHITE, b["rect"])
            if fever:
                pygame.draw.ellipse(buffer, YELLOW, b["rect"], 2)

        # 대기 공
        if waiting and wait_ball:
            if (blink_timer // 15) % 2 == 0:
                pygame.draw.ellipse(buffer, YELLOW, wait_ball["rect"])

        # 패들
        pygame.draw.rect(buffer, WHITE, pad, border_radius=4)
        if fever:
            pygame.draw.rect(buffer, YELLOW, pad, 2, border_radius=4)

        # ★ 아이템 그리기 (ItemSprite.draw)
        for item in items:
            item.draw(buffer)

        # 기존 circle 파티클
        for p in particles:
            col  = p[5] if len(p) > 5 else YELLOW
            size = max(1, int(3 * p[4] / 20))
            pygame.draw.circle(buffer, col, (int(p[0]), int(p[1])), size)

        # ── 상단 UI 바 ────────────────────────────────────────
        pygame.draw.rect(buffer, DARK_GRAY, (0, 0, WIDTH, 50))
        pygame.draw.line(buffer, (60, 60, 80), (0, 50), (WIDTH, 50), 1)

        draw_text_buf(buffer, f"SCORE", 20, 5, (160,160,160), en_small_font)
        draw_text_buf(buffer, f"{score:,}", 20, 20, YELLOW, en_ui_font)
        draw_text_buf(buffer, f"BEST", 170, 5, (160,160,160), en_small_font)
        draw_text_buf(buffer, f"{highscore:,}", 170, 20, WHITE, en_ui_font)

        score_anim_timer += dt / 1000.0
        pulse = abs(math.sin(score_anim_timer * 1.2))
        sc_size = int(28 + pulse * 6)
        sc_fnt = pygame.font.SysFont("arial", sc_size, bold=True)
        sc_surf = sc_fnt.render(f"{score:,}", True, WHITE)
        buffer.blit(sc_surf, (WIDTH//2 - sc_surf.get_width()//2, 10))

        for i in range(lives):
            buffer.blit(heart_frames[heart_idx], (WIDTH - 40 - i*30, 13))

        # 대기 안내
        if waiting:
            msg = font.render("E 키로 발사!", True, YELLOW)
            buffer.blit(msg, (WIDTH//2 - msg.get_width()//2, HEIGHT//2 - 30))

        # 피버 플래시
        if now < fever_flash_end:
            flash_ratio = (fever_flash_end - now) / 1.2
            alpha = int(255 * flash_ratio)
            if int((fever_flash_end - now) * 8) % 2 == 0:
                t_surf = fever_title_font.render("FEVER!", True, YELLOW)
                fs = pygame.Surface(t_surf.get_size(), pygame.SRCALPHA)
                fs.blit(t_surf, (0, 0))
                fs.set_alpha(alpha)
                buffer.blit(fs, (WIDTH//2 - t_surf.get_width()//2,
                                 HEIGHT//2 - t_surf.get_height()//2 - 40))

        # ── 하단 UI 바 ────────────────────────────────────────
        pygame.draw.rect(buffer, DARK_GRAY, (0, HEIGHT-65, WIDTH, 65))
        pygame.draw.line(buffer, (60, 60, 80), (0, HEIGHT-65), (WIDTH, HEIGHT-65), 1)

        btn_x, btn_y = 10, HEIGHT - 54
        if skill_img:
            if skills > 0:
                buffer.blit(skill_img, (btn_x, btn_y))
            else:
                dark = skill_img.copy()
                dark.set_alpha(80)
                buffer.blit(dark, (btn_x, btn_y))
            count_x = btn_x + 44 + 6
            count_y = btn_y + 10
            if skills > 0:
                ck = BLUE if (blink_timer // 20) % 2 == 0 else WHITE
                draw_text_buf(buffer, f"x{skills}", count_x, count_y, ck, font)
            else:
                draw_text_buf(buffer, "x0", count_x, count_y, (80, 80, 80), font)
        else:
            slot_rect = pygame.Rect(btn_x, btn_y, 140, 44)
            pygame.draw.rect(buffer, (35, 35, 55), slot_rect, border_radius=8)
            if skills > 0:
                ck = BLUE if (blink_timer // 20) % 2 == 0 else WHITE
                draw_text_buf(buffer, f"SKILL [E] x{skills}", btn_x + 6, btn_y + 12, ck, ui_font)
            else:
                draw_text_buf(buffer, "SKILL [E] x0", btn_x + 6, btn_y + 12, (80,80,80), ui_font)

        if paddle_duration > 0:
            pad_ratio = max(0.0, paddle_duration / 7.0)
            blink_on  = (blink_timer // 15) % 2 == 0
            pad_col   = WHITE if (paddle_duration < 2.0 and blink_on) else BLUE
            px = 120
            lbl = small_font.render("패들 확장!", True, pad_col)
            buffer.blit(lbl, (px, HEIGHT - 54))
            pg_bg = pygame.Rect(px, HEIGHT - 36, 100, 8)
            pygame.draw.rect(buffer, (20, 20, 50), pg_bg, border_radius=4)
            pygame.draw.rect(buffer, pad_col,
                             (pg_bg.x, pg_bg.y, int(100 * pad_ratio), 8), border_radius=4)
            sec_txt = small_font.render(f"{max(0.0, paddle_duration):.1f}s", True, pad_col)
            buffer.blit(sec_txt, (px, HEIGHT - 24))
        else:
            hint = small_font.render("★ 노란 블록 = 아이템 60%", True, (140, 130, 40))
            buffer.blit(hint, (120, HEIGHT - 36))

        if fever:
            draw_text_buf(buffer, "!! 피버 타임 !!", WIDTH//2, HEIGHT-58, RED, ui_font, center=True)
            ratio = max(0.0, (fever_end - now) / FEVER_DURATION)
            gauge_bg = pygame.Rect(WIDTH//2 - 110, HEIGHT-40, 220, 12)
            pygame.draw.rect(buffer, (60, 30, 30), gauge_bg, border_radius=6)
            pygame.draw.rect(buffer, RED,
                             (gauge_bg.x, gauge_bg.y, int(220 * ratio), 12), border_radius=6)

        elif combo > 0:
            fill_ratio = min(combo / FEVER_TARGET, 1.0)
            col = combo_color(fill_ratio)
            combo_fnt = pygame.font.SysFont("arial", 16 + min(combo, 6), bold=True)
            draw_text_buf(buffer, f"{combo}  COMBO", WIDTH//2, HEIGHT-58, col, combo_fnt, center=True)

            gauge_bg = pygame.Rect(WIDTH//2 - 110, HEIGHT-40, 220, 12)
            pygame.draw.rect(buffer, (60, 60, 60), gauge_bg, border_radius=6)
            pygame.draw.rect(buffer, col,
                             (gauge_bg.x, gauge_bg.y, int(220 * fill_ratio), 12), border_radius=6)

            time_ratio = max(0.0, 1.0 - (now - combo_time) / FEVER_LIMIT)
            timer_col  = (int(255 * (1 - time_ratio)), int(200 * time_ratio), 50)
            timer_bg   = pygame.Rect(WIDTH//2 - 110, HEIGHT-22, 220, 6)
            pygame.draw.rect(buffer, (50, 50, 50), timer_bg, border_radius=3)
            pygame.draw.rect(buffer, timer_col,
                             (timer_bg.x, timer_bg.y, int(220 * time_ratio), 6), border_radius=3)

        draw_scanlines(buffer, alpha=12)

        ox, oy = get_shake_offset()
        shaken = pygame.Surface((NATIVE_W, NATIVE_H))
        shaken.fill((0, 0, 0))
        shaken.blit(buffer, (ox, oy))
        blit_scaled(shaken, screen)
        pygame.display.flip()


if __name__ == "__main__":
    main()
